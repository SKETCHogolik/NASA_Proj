import pandas as pd
from src.ranking.relevance import rank_experiments

def test_ranker_returns_numeric_scores():
    df = pd.DataFrame([{"title":"Saffire fire test","abstract":"ISS combustion","mission":"ISS",
                        "program":"Saffire","pressure_kpa":100.0,"oxygen_pct":22.0,"url":"https://example.org"}])
    ranked = rank_experiments(df)
    assert 0 <= ranked.iloc[0]["relevance_score"] <= 100
