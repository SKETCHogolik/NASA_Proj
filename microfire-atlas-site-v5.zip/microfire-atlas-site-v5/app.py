from pathlib import Path
import base64
import json
import pandas as pd
import streamlit as st
import plotly.express as px
import streamlit.components.v1 as components

ROOT = Path(__file__).parent
DATA = ROOT / "data" / "processed"
IMAGES = ROOT / "data" / "images"
st.set_page_config(page_title="Microfire Atlas", page_icon="🔥", layout="wide", initial_sidebar_state="collapsed")

# ---------- Shared visual shell ----------
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
:root { color-scheme: dark; }
html, body, [class*="css"] { font-family: Inter, sans-serif; }
.stApp { background: radial-gradient(ellipse at 65% 8%, #0b1b38 0%, #050b18 52%, #030711 100%); color:#eaf1ff; }
header[data-testid="stHeader"], footer, #MainMenu { visibility:hidden; height:0; }
.block-container { padding-top: .6rem !important; padding-bottom: 2rem !important; max-width: 1600px; }
div[data-testid="stToolbar"] { display:none; }
.topnav { display:flex; justify-content:center; align-items:center; gap:12px; padding:10px 0 18px; }
.topnav a { color:#c7d8f5; text-decoration:none; border:1px solid #1b3b6c; background:rgba(7,25,54,.78);
 padding:10px 19px; border-radius:999px; font-size:13px; transition:.22s ease; }
.topnav a:hover, .topnav a.active { color:white; border-color:#4389ee; background:linear-gradient(120deg,#0b3d91,#1261bb); box-shadow:0 0 22px #1b65bd55; transform:translateY(-1px); }
h1,h2,h3 { letter-spacing:-.03em; }
div[data-testid="stMetric"] { background:linear-gradient(145deg,#0a1c39,#071329); border:1px solid #17365e; padding:14px 16px; border-radius:16px; }
div[data-testid="stTabs"] button { color:#a9c2e8; }
div[data-testid="stTabs"] button[aria-selected="true"] { color:#fff; }
div[data-testid="stDataFrame"] { border:1px solid #1b3559; border-radius:14px; overflow:hidden; }
section[data-testid="stSidebar"] { display:none; }
a { color:#72b6ff; }
</style>
""", unsafe_allow_html=True)

def nav(page):
    links = [
        ("home","Home"),("fire","Fire in Space"),("dashboard","Research Dashboard")
    ]
    html = '<div class="topnav">'
    for key,label in links:
        cls = "active" if page == key else ""
        html += f'<a class="{cls}" href="?page={key}" target="_top">{label}</a>'
    html += '</div>'
    st.markdown(html, unsafe_allow_html=True)

@st.cache_data
def svg_data(name):
    path = IMAGES / f"{name}.svg"
    raw = path.read_bytes()
    return "data:image/svg+xml;base64," + base64.b64encode(raw).decode("ascii")

# ---------- Slide site / responsive image-map hitboxes ----------
PAGES = {
 "home": ("Main", "Home"),
 "fire": ("Fire in Space", "Fire in Space"),
 "apollo": ("Fire_in_Space_Apollo_1_1967", "Apollo 1 · 1967"),
 "mir": ("Fire_in_Space_Mir_1997", "Mir · 1997"),
 "artemis": ("Fire_in_Space_Artemis_II", "Artemis II"),
 "bass": ("BASS", "BASS"),
 "microgravity": ("Microgravity", "Microgravity"),
 "saffire": ("Saffire", "Saffire"),
 "gases": ("Gases_Smoke", "Gases & Smoke"),
 "limits": ("Limits", "Limits"),
 "screwups": ("Screw_ups", "Screw-ups"),
}
SIDE_LINKS = [
 ("fire","Fire in Space",248,310),
 ("bass","BASS",312,372),
 ("microgravity","Microgravity",374,436),
 ("saffire","Saffire",438,500),
 ("gases","Gases & Smoke",502,562),
 ("limits","Limits",564,624),
 ("screwups","Screw-ups",626,688),
]
def render_slide(page):
    key, title = PAGES[page]
    data = svg_data(key)
    hotspots = []
    # All slide designs include the same left-hand topic navigation.
    for target,label,y1,y2 in SIDE_LINKS:
        hotspots.append(f'<a class="hit side" href="?page={target}" target="_top" aria-label="{label}" title="{label}" style="left:0;top:{y1/1180*100:.4f}%;width:18.15%;height:{(y2-y1)/1180*100:.4f}%"></a>')
    # The three story cards are clickable on the Fire in Space overview and animate on hover.
    if page == "fire":
        cards = [("apollo",17.5,26.5,19.0,49.0),("mir",39.5,26.5,21.5,49.0),("artemis",62.0,26.5,22.0,49.0)]
        for target,x,y,w,h in cards:
            hotspots.append(f'<a class="hit story" href="?page={target}" target="_top" style="left:{x}%;top:{y}%;width:{w}%;height:{h}%" aria-label="Open {PAGES[target][1]}"></a>')
    # On detail slides, each of the three story cards remains a working hitbox.
    if page in ("apollo","mir","artemis"):
        cards = [("apollo",19.0,24.0,25.5,51.0),("mir",42.0,24.0,25.5,51.0),("artemis",65.0,24.0,25.0,51.0)]
        for target,x,y,w,h in cards:
            hotspots.append(f'<a class="hit story" href="?page={target}" target="_top" style="left:{x}%;top:{y}%;width:{w}%;height:{h}%" aria-label="Open {PAGES[target][1]}"></a>')
    # Return to landing page by clicking the logo block.
    hotspots.append('<a class="hit logo" href="?page=home" target="_top" style="left:1.5%;top:1.5%;width:16%;height:16%" aria-label="Home"></a>')
    # Home hero text itself is also an entry point to Fire in Space.
    if page == "home":
        hotspots.append('<a class="hit hero" href="?page=fire" target="_top" style="left:30%;top:65%;width:43%;height:15%" aria-label="Explore Fire in Space"></a>')
    overlay = "".join(hotspots)
    html = f"""
    <!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
      *{{box-sizing:border-box}} html,body{{margin:0;background:#030914;width:100%;}}
      .stage{{position:relative;width:min(100%, calc((100vh - 155px) * 1.627));margin:0 auto;aspect-ratio:1920/1180;overflow:hidden;border:1px solid #17345b;border-radius:18px;box-shadow:0 22px 70px #0009;}}
      .slide{{position:absolute;inset:0;width:100%;height:100%;object-fit:fill;display:block;}}
      .hit{{position:absolute;display:block;z-index:5;border:1px solid transparent;border-radius:14px;outline:none;transition:background .22s,border .22s,box-shadow .22s,transform .22s;}}
      .hit:hover,.hit:focus-visible{{background:rgba(32,125,255,.13);border:1px solid rgba(108,180,255,.8);box-shadow:0 0 24px rgba(36,128,255,.32),inset 0 0 20px rgba(36,128,255,.13);}}
      .hit.story:hover{{transform:scale(1.025);background:rgba(68,150,255,.10);}}
      .hit.side{{border-radius:8px;}}
      .hit.side:hover{{background:rgba(36,117,235,.2);transform:translateX(3px);}}
      .hint{{position:absolute;z-index:6;right:1.5%;bottom:1.4%;color:#9dbce7;background:#061a35cc;border:1px solid #234a7b;border-radius:99px;padding:7px 12px;font:11px Inter,Arial;opacity:0;transition:.2s;pointer-events:none}}
      .stage:hover .hint{{opacity:1}}
      @media(max-width:700px){{.stage{{border-radius:8px}}}}
    </style></head><body>
      <div class="stage"><img class="slide" src="{data}" alt="{title} slide">{overlay}
      <div class="hint">Hover over a panel · Click to explore</div></div>
    </body></html>
    """
    components.html(html, height=900, scrolling=False)
    st.caption("Interactive design slide · Hover over highlighted panels and click to open a topic. Use the top navigation to return to the dashboard.")

# ---------- Research data ----------
@st.cache_data
def load_data():
    frames=[]
    p=DATA/"microfire-atlas-bass2-tests.csv"
    if p.exists():
        d=pd.read_csv(p)
        frames.append(pd.DataFrame({"test_id":d["test_id"],"program":d["investigation"],"material":d["material"],
          "pressure_kpa":pd.to_numeric(d["pressure_kpa"],errors="coerce"),"oxygen_pct":pd.to_numeric(d["oxygen_vol_pct"],errors="coerce"),
          "flow_cm_s":pd.to_numeric(d["flow_final_cm_s"],errors="coerce"),"outcome":d["outcome_label"],"source_id":d["source_id"],
          "page":d["pdf_page"],"gravity":"Microgravity (ISS)","evidence_source":"BASS-II source table"}))
    p=DATA/"microfire-atlas-saffire-runs.csv"
    if p.exists():
        d=pd.read_csv(p)
        frames.append(pd.DataFrame({"test_id":d["flight"].astype(str)+" · "+d["sample"].astype(str),"program":"Saffire","material":d["material"],
          "pressure_kpa":pd.to_numeric(d["pressure_kpa"],errors="coerce"),"oxygen_pct":pd.to_numeric(d["o2_pct"],errors="coerce"),
          "flow_cm_s":pd.to_numeric(d["flow_cm_s"],errors="coerce"),"outcome":d["outcome_label"],
          "source_id":d["conditions_source"].fillna(d["results_source"]),"page":d["conditions_pdf_page"].fillna(d["results_pdf_page"]),
          "gravity":"Microgravity (free-flying Cygnus)","evidence_source":"Saffire test record"}))
    p=DATA/"microfire-atlas-luci-runs.csv"
    if p.exists():
        d=pd.read_csv(p)
        frames.append(pd.DataFrame({"test_id":"LUCI · "+d["sample"].astype(str),"program":"LUCI","material":d["material"],
          "pressure_kpa":pd.to_numeric(d["pressure_kpa"],errors="coerce"),"oxygen_pct":pd.to_numeric(d["o2_start_pct"],errors="coerce"),
          "flow_cm_s":pd.to_numeric(d["spread_tip_mm_s"],errors="coerce"),"outcome":d["outcome_label"],"source_id":d["source_id"],
          "page":d["outcome_pdf_page"],"gravity":d["gravity"].astype(str),"evidence_source":"LUCI test record"}))
    return pd.concat(frames,ignore_index=True) if frames else pd.DataFrame()

SOURCE_URLS={"bass2-summary":"https://ntrs.nasa.gov/citations/20210011385","bass2-results":"https://ntrs.nasa.gov/citations/20160000593",
 "saffire-1-3":"https://ntrs.nasa.gov/citations/20170008805","saffire-4-5":"https://ntrs.nasa.gov/citations/20210017780",
 "saffire-6":"https://ntrs.nasa.gov/citations/20240002981","luci":"https://ntrs.nasa.gov/citations/20250010653"}

def render_dashboard():
    df=load_data()
    st.title("Research Dashboard")
    st.caption("NASA spacecraft-fire research · BASS / BASS-II · Saffire · LUCI")
    with st.expander("Filters",expanded=True):
        c1,c2,c3=st.columns([1.2,1.2,1])
        with c1: programs=st.multiselect("Program",sorted(df.program.dropna().unique()),default=sorted(df.program.dropna().unique()))
        with c2: materials=st.multiselect("Material",sorted(df.material.dropna().unique()),default=sorted(df.material.dropna().unique()))
        with c3:
            pressure=st.slider("Pressure (kPa)",0.0,110.0,(0.0,110.0),0.5)
            oxygen=st.slider("O₂ (vol. %)",0.0,40.0,(0.0,40.0),0.5)
    view=df[df.program.isin(programs)&df.material.isin(materials)].copy()
    measured=view.dropna(subset=["pressure_kpa","oxygen_pct"])
    measured=measured[measured.pressure_kpa.between(*pressure)&measured.oxygen_pct.between(*oxygen)]
    a,b,c,d=st.columns(4)
    a.metric("Test records",len(view)); b.metric("BASS / BASS-II",int(view.program.str.contains("BASS",na=False).sum()))
    c.metric("Saffire",int((view.program=="Saffire").sum())); d.metric("Points on map",len(measured))
    overview,coverage,records,findings=st.tabs(["Overview","Pressure × O₂ map","Test records","Research findings"])
    with overview:
        l,r=st.columns(2)
        with l: st.plotly_chart(px.bar(view.groupby("program").size().reset_index(name="tests"),x="program",y="tests",color="program",title="Records by program"),use_container_width=True)
        with r: st.plotly_chart(px.bar(view["outcome"].fillna("Not stated").value_counts().rename_axis("outcome").reset_index(name="tests"),x="tests",y="outcome",orientation="h",title="Recorded outcomes"),use_container_width=True)
    with coverage:
        st.subheader("Experimental conditions")
        if measured.empty: st.warning("No records with both pressure and O₂ match the current filters.")
        else:
            fig=px.scatter(measured,x="pressure_kpa",y="oxygen_pct",color="program",symbol="program",hover_name="test_id",
              hover_data=["material","gravity","flow_cm_s","outcome","source_id","page"],
              labels={"pressure_kpa":"Pressure (kPa)","oxygen_pct":"Oxygen (vol. %)"})
            fig.update_traces(marker={"size":12,"opacity":.85})
            fig.update_layout(height=620,xaxis_title="Pressure (kPa)",yaxis_title="O₂ concentration (vol. %)")
            st.plotly_chart(fig,use_container_width=True)
            st.caption(f"{len(measured)} records plotted. Missing conditions are not imputed.")
    with records:
        show=view.copy(); show["source_url"]=show["source_id"].map(SOURCE_URLS)
        st.dataframe(show[["test_id","program","material","pressure_kpa","oxygen_pct","flow_cm_s","gravity","outcome","source_id","page","source_url"]],
          use_container_width=True,hide_index=True,column_config={"source_url":st.column_config.LinkColumn("NASA source")})
        st.download_button("Download filtered CSV",show.to_csv(index=False).encode(),"microfire-atlas-filtered.csv","text/csv")
    with findings:
        f=DATA/"microfire-atlas-findings.json"
        if f.exists():
            raw=json.loads(f.read_text(encoding="utf-8"))
            st.write(f"{len(raw)} extracted findings in the uploaded dataset.")
            for item in raw[:80]:
                if isinstance(item,dict):
                    title=item.get("id") or item.get("kind") or "Finding"
                    with st.expander(str(title)):
                        st.write(item.get("quote") or item.get("text") or item)
        else: st.info("No findings JSON found.")

# ---------- Router ----------
page=st.query_params.get("page","home")
if page not in PAGES and page!="dashboard": page="home"
nav(page)
if page=="dashboard":
    render_dashboard()
else:
    title=PAGES[page][1]
    if page=="home":
        st.markdown("<div style='text-align:center;color:#8fb8ee;font-size:12px;letter-spacing:.22em;margin:0 0 8px'>NASA SPACE FIRE SAFETY</div>",unsafe_allow_html=True)
    render_slide(page)
