# Freddy Fazbear's Pizza: Lunar Shift
## Compact game design brief — Godot 4

### High concept
First-person survival-management horror inspired by the FNAF formula. The player is Michael Afton, operating a lunar pizzeria while hostile animatronics roam the habitat. The horror comes from managing a fragile life-support system while defending the office.

### Core loop
1. Check cameras, room pressure and oxygen distribution.
2. Predict animatronic movement and choose which threat to counter.
3. Manage doors; sealed doors buy safety but create pressure-management penalties.
4. Respond to sabotage, vent threats and fire.
5. Isolate oxygen, equip a suit, reach the fire and extinguish it when possible.
6. Survive until 06:00.

### Core systems
- **Pressure:** local pressure changes with door state and habitat leaks. Prolonged sealed-door use pushes pressure outside safe operating bounds.
- **Oxygen network:** a separate oxygen plant supplies rooms through ventilation. Plant damage reduces or stops replenishment.
- **Emergency cylinder:** limited portable oxygen needed to safely intervene during a plant fire.
- **Fire:** consumes oxygen and spreads through connected spaces. The player must isolate the oxygen feed, put on a suit and extinguish the source.
- **Doors:** block routes but have durability and cannot be held closed indefinitely.
- **Map/cameras:** Office, Left Hall, Right Hall, Kitchen, Ventilation and Oxygen Plant.

### Animatronics
| Character | Behaviour | Counterplay |
|---|---|---|
| Freddy | Damages oxygen plant | Watch plant camera; isolate/repair before supply fails |
| Bonnie | Breaks a door | Detect approach; use alternate route and repair |
| Chica | Chooses office or kitchen; Cupcake may crawl through vent | Track Chica and inspect vent |
| Foxy | Runs toward office | Monitor staging area and react to the sprint tell |
| Balloon Boy | Steals spare oxygen cylinder | Keep him out; losing it makes fire response dangerous |
| Mangle | Plays an archived NASA emergency recording | Audio clue; playback may mask other sounds |
| Helpy | Tutorial guide | Teaches controls and emergency procedures |
| Springtrap | Activates Night 4; can arrive from any connected room and sabotage plant | Use sound and system checks; no permanently safe route |

### Night progression
- **Night 1:** Helpy tutorial; pressure, oxygen, cameras; Freddy and Bonnie introduced gently.
- **Night 2:** Chica and Cupcake; ventilation monitoring.
- **Night 3:** Foxy and Balloon Boy; emergency cylinder becomes strategic.
- **Night 4:** Springtrap activates; threats can emerge from unexpected routes.
- **Night 5:** Oxygen plant fire is inevitable. The player can delay the cascade and make meaningful emergency decisions, but cannot save the pizzeria.

### Narrative
Mangle's NASA recording is fictional in-game archival audio from an earlier spacecraft emergency, not a real NASA recording. It reveals the station's history in fragments. Helpy's cheerful tutorial tone becomes increasingly disturbing as systems fail.

### Ending
On the final night, the oxygen room inevitably ignites. The player can protect the office, attempt evacuation and delay spread, but the pizzeria and animatronics are ultimately destroyed. Foreshadow this through earlier faults and recordings so the ending feels tragic and earned, not arbitrary.

### First playable prototype
Build one night before expanding: office scene, clock/HUD, five-room node map, pressure and oxygen variables, two doors with durability, Freddy plant sabotage, one complete fire emergency, win/lose states and event log.

### Godot architecture
- `GameState.gd`: night, clock, global state, win/lose.
- `LifeSupport.gd`: oxygen production/distribution, pressure, fire propagation.
- `AnimatronicDirector.gd`: enemy schedules and state transitions.
- `AnimatronicBase.gd`: shared states `IDLE`, `MOVING`, `ATTACKING`, `DISABLED`.
- `OfficeUI.gd`: HUD, doors, cameras/map.
- `EventLog.gd`: Helpy tutorial, NASA recording and emergency messages.

### Design rules
Pressure and oxygen must be separate variables with distinct consequences. Every enemy needs a readable tell, a countermeasure and a cost for ignoring it. The inevitable finale must be foreshadowed and mechanically legible.
