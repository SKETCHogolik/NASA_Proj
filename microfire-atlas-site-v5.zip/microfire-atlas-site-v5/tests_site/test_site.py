import importlib.util, pathlib, re, sqlite3, unittest, json
ROOT=pathlib.Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('microfire_site',ROOT/'site.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class SiteTests(unittest.TestCase):
 def test_slide_assets(self):
  names=['Main','Fire in Space','Fire_in_Space_Apollo_1_1967','Fire_in_Space_Mir_1997','Fire_in_Space_Artemis_II','BASS','Microgravity','Saffire','Gases_Smoke','Limits','Screw_ups']
  for n in names:
   p=ROOT/'static'/'slides'/f'{n}.svg';self.assertTrue(p.is_file(),n)
   self.assertIn('viewBox="0 0 1920 1180"',p.read_text()[:200])
 def test_navigation_geometry(self):
  coords=[296,366,440,496,552,606,662]
  for y in coords:self.assertTrue(0<y-23<y+23<1180)
  for a,b in zip(coords,coords[1:]):self.assertGreaterEqual(b-a,46)
  js=(ROOT/'static'/'site.js').read_text()
  self.assertIn('a.addEventListener(\'click\'',js)
  self.assertIn("current===target?' active'",js)
  self.assertIn('history.pushState',js)
 def test_data_and_coverage(self):
  m.init_db()
  with m.connect() as c:rows=[dict(x) for x in c.execute('SELECT * FROM measurements')]
  q=m.metrics(rows)
  self.assertEqual(q['records'],78)
  self.assertEqual(q['pressure_ranges'],22)
  self.assertGreaterEqual(q['plotted'],60)
  self.assertEqual(sum(q['by_program'].values()),78)
 def test_validation(self):
  d={'test_id':'QA','program':'BASS','pressure_kpa':101.3,'oxygen_pct':21,'flow_cm_s':None,'source_id':'doc','status':'draft'}
  self.assertEqual(m.valid(d),[])
  self.assertTrue(m.valid({**d,'oxygen_pct':101}))
  self.assertTrue(m.valid({**d,'status':'reviewed','source_id':'','source_url':''}))
 def test_sources(self):
  self.assertEqual(len(m.ARTICLES),4)
  self.assertEqual(len(set(x[0] for x in m.ARTICLES)),4)
if __name__=='__main__':unittest.main()
