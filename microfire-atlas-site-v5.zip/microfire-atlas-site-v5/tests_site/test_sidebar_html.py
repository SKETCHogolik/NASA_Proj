from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def test_sidebar_text_is_html():
    js=(ROOT/'static/site.js').read_text()
    assert "a.textContent=r.label||names[target]" in js
    assert "a.setAttribute('aria-current'" in js

def test_sidebar_svg_labels_are_masked():
    for p in (ROOT/'static/slides').glob('*.svg'):
        s=p.read_text()
        assert 'Sidebar labels replaced by accessible HTML navigation' in s
        assert '<rect x="0" y="274" width="352" height="442"' in s
