# Microfire Atlas v2 — interactive website + research dashboard

## Start (Python standard library only)

```bash
python site.py
```

Open **http://127.0.0.1:8502**. The original Streamlit dashboard remains in `app.py` for reference, but the **new integrated site** is launched using `site.py`.

### Enable editing (local)

```bash
MICROFIRE_ADMIN_TOKEN='choose-a-long-random-password' python site.py
```

Open **Data Editor**, enter the same token, and add a record. SQLite database is created at `data/microfire.sqlite3` on first run. Back up this file before deployment or upgrades. The default server binds to `127.0.0.1` (not publicly exposed). Do not publicly expose the editor without authentication, HTTPS and persistent storage; a single shared admin token is intended only for local administration.

## Features

- All 11 supplied designer SVG slides retained.
- Accurate proportional hitboxes for left menu and Apollo/Mir/Artemis cards, using original 1920 × 1180 coordinates.
- Selected sidebar item is white in the original SVG, plus an active white selection rail.
- Native single-page routing and browser history; no iframe navigation.
- Local Plotly.js with slide-matched dark blue style and legends (works offline).
- SQLite-backed measurements; form with server-side validation, draft/reviewed status, provenance and numeric bounds.
- Data quality summary: missing values, repeated test labels, record status.
- Source library includes four supplied CyberLeninka links. The ISS combustion article requires CAPTCHA, so it is catalogued without invented extracted facts.

## Scientific caveats

- Source links are not numeric measurements. No quantitative values were extracted from the four CyberLeninka articles for this release.
- Missing pressure/O₂ values remain null; empty map areas are not necessarily untested.
- LUCI uses starting oxygen concentration; do not treat it as equivalent to a constant-oxygen experiment.
- An imported record is not automatically independently verified.
- The existing source data, articles and design artwork retain their own reuse terms; MIT applies only to original project code.

## Testing

Run `python -m unittest discover -s tests_site -v`. Browser tests (Playwright + Chromium) are in `tests_site/browser_smoke.py` and can be run when dependencies are installed.


## v3 navigation fix
The sidebar is a real HTML navigation layer positioned in the SVG's 1920×1180 coordinate system. Labels are redrawn over the baked-in menu labels so the active item always turns white. The original slides are untouched.

## v4 navigation alignment
Removed the second layer of sidebar text, which previously doubled and shifted the designer's SVG labels. Hitboxes are transparent and positioned over the existing SVG menu. Active labels are already white in their respective slide artwork. Corrected Fire/BASS vertical coordinates and Fire in Space card hitboxes from the user screenshot.

## Sidebar navigation update
Designer-rendered sidebar labels are covered inside SVG assets. Sidebar labels are rendered as accessible HTML anchors in `static/site.js`, with active route white.
