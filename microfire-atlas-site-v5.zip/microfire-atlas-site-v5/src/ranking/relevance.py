def rank_experiments(df):
 out=df.copy(); out['relevance_score']=90
 out.loc[out['pressure_kpa'].notna() & out['oxygen_pct'].notna(),'relevance_score']=100
 return out
