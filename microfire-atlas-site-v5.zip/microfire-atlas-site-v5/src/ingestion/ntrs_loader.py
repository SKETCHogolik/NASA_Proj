"""NASA NTRS OpenAPI citation search."""
import requests

ENDPOINT = "https://ntrs.nasa.gov/api/citations/search"

def search_ntrs(query: str, limit: int = 30):
    # NTRS exposes POST /citations/search. Keep request fields minimal and
    # tolerate API schema changes rather than fabricating records.
    payload = {"query": query, "page": 0, "pageSize": limit}
    response = requests.post(ENDPOINT, json=payload, timeout=30,
                             headers={"Accept":"application/json","Content-Type":"application/json",
                                      "User-Agent":"space-fire-research-dashboard/0.1"})
    if response.status_code in (400, 422):
        # Current NTRS API versions may use different search field names.
        # Return no records and leave the PSI source available.
        return []
    response.raise_for_status()
    body = response.json()
    items = body.get("results") or body.get("items") or body.get("citations") or []
    rows = []
    for item in items[:limit]:
        meta = item.get("citation") if isinstance(item.get("citation"), dict) else item
        rid = str(meta.get("id") or meta.get("stiId") or meta.get("legacyId") or "")
        title = meta.get("title") or meta.get("titleOfWork") or "Untitled NASA record"
        abstract = meta.get("abstract") or meta.get("description") or ""
        url = f"https://ntrs.nasa.gov/citations/{rid}" if rid else "https://ntrs.nasa.gov/"
        low = (title + " " + abstract).lower()
        program = "BASS" if "bass" in low else ("Saffire" if "saffire" in low else "Other")
        mission = "ISS" if "iss" in low or "international space station" in low else ("Space Shuttle" if "shuttle" in low else "Ground")
        rows.append({"record_id":rid or url,"source":"NTRS","title":title,"abstract":abstract,
                     "url":url,"program":program,"mission":mission,"pressure_kpa":None,"oxygen_pct":None})
    return rows
