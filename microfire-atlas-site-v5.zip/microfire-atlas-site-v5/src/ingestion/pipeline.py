import pandas as pd
# Table 1: Saffire IV-V Sample Test Conditions, NASA-hosted NTRS report 20210011521.
URL='https://ntrs.nasa.gov/api/citations/20210011521/downloads/ICES%202021-266%200503-2021%20final.pdf'
ROWS=[
('Saffire IV-1','SIBAL cloth flame test','SIBAL cloth',100.0,22.0),
('Saffire IV-2','Two-sided PMMA flame test','PMMA, two-sided',100.0,22.0),
('Saffire V-2','Cotton jersey flame test','Cotton jersey',70.7,26.2),
('Saffire V-3','One-sided PMMA flame test','PMMA, one-sided',71.3,25.4),
('Saffire V-4','Structured PMMA flame test','Structured PMMA',72.6,25.7),]
def load_verified_dataset():
 return pd.DataFrame([{'test_id':i,'program':'Saffire','title':t,'material':m,'pressure_kpa':p,'oxygen_pct':o,'evidence_source':'NASA report table','source_url':URL} for i,t,m,p,o in ROWS])
