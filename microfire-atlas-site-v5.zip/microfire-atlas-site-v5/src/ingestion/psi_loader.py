"""NASA PSI public repository search adapter.

The PSI 2.0 website is the authoritative discovery UI. Its internal search
backend is not treated as a stable public API; this adapter uses the public
search route and fails softly if NASA changes it.
"""
import requests
from bs4 import BeautifulSoup

BASE = "https://psi.nasa.gov/physci/repo/search"

def search_psi(query: str, limit: int = 30):
    params = {"q": query, "data_source": "psi", "data_type": "investigation"}
    response = requests.get(BASE, params=params, timeout=30, headers={"User-Agent":"space-fire-research-dashboard/0.1"})
    response.raise_for_status()
    soup = BeautifulSoup(response.text, "html.parser")
    rows, seen = [], set()
    for a in soup.select('a[href*="/physci/repo/"]'):
        href = a.get("href", "")
        title = " ".join(a.get_text(" ", strip=True).split())
        if not title or href.rstrip("/") == "/physci/repo":
            continue
        url = href if href.startswith("http") else "https://psi.nasa.gov" + href
        if url in seen: continue
        seen.add(url)
        text = " ".join(a.parent.get_text(" ", strip=True).split())[:1200]
        rows.append(_record(url, title, text))
        if len(rows) >= limit: break
    return rows

def _record(url, title, abstract):
    low = (title + " " + abstract).lower()
    program = "BASS" if "bass" in low else ("Saffire" if "saffire" in low else "Other")
    mission = "ISS" if any(x in low for x in ["iss","international space station"]) else ("Space Shuttle" if "shuttle" in low else "Ground")
    import re
    p = re.search(r'(\d+(?:\.\d+)?)\s*kpa', low)
    o = re.search(r'(\d+(?:\.\d+)?)\s*(?:mol\s*)?%\s*(?:o2|oxygen)', low)
    return {"record_id":url.rsplit("/",1)[-1],"source":"PSI","title":title,"abstract":abstract,
            "url":url,"program":program,"mission":mission,
            "pressure_kpa":float(p.group(1)) if p else None,
            "oxygen_pct":float(o.group(1)) if o else None}
