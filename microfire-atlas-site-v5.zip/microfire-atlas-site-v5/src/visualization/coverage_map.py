import pandas as pd
import plotly.express as px

def make_coverage_figure(df: pd.DataFrame):
    valid = df.dropna(subset=["pressure_kpa","oxygen_pct"]).copy()
    if valid.empty:
        fig = px.scatter(title="No verified pressure × O₂ measurements in current import")
        fig.update_layout(xaxis_title="Pressure (kPa)", yaxis_title="O₂ (mol %)")
        return fig
    fig = px.scatter(valid, x="pressure_kpa", y="oxygen_pct", color="program",
                     hover_name="title", hover_data=["source","record_id"],
                     labels={"pressure_kpa":"Pressure (kPa)","oxygen_pct":"O₂ (mol %)"})
    fig.update_traces(marker={"size":12, "opacity":0.85})
    fig.update_layout(title="Observed experimental conditions", legend_title="Program")
    return fig
