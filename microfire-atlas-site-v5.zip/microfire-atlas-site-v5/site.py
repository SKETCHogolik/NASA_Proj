"""Microfire Atlas: standalone web app with SQLite and offline Plotly."""
import csv, json, math, os, re, sqlite3, threading
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from urllib.parse import urlparse, parse_qs

ROOT=Path(__file__).resolve().parent
DB=ROOT/'data'/'microfire.sqlite3'
LOCK=threading.RLock()
ALLOWED={'BASS','BASS-II','Saffire','LUCI','Other'}
ARTICLES=[
 ('iss-combustion','Исследования процессов горения на стенде Международной космической станции','https://cyberleninka.ru/article/n/issledovaniya-protsessov-goreniya-na-stende-mezhdunarodnoy-kosmicheskoy-stantsii','microgravity','Ссылка предоставлена пользователем; полный текст не извлечён из-за проверки CAPTCHA.','unverified'),
 ('orbital-fire-suppression','Технология пожаротушения в обитаемых герметичных отсеках модулей космических летательных аппаратов в орбитальном полёте','https://cyberleninka.ru/article/n/tehnologiya-pozharotusheniya-v-obitaemyh-germetichnyh-otsekah-moduley-kosmicheskih-letatelnyh-apparatov-v-orbitalnom-polyote','limits','Мелихов, Мордвинова, Истомин (2017): опасность пожаров в гермоотсеках, ограничения массы, вентиляция и средства тушения.','reviewed'),
 ('water-mist-review','The review of the water mist fire extinguishing technology','https://cyberleninka.ru/article/n/the-review-of-the-water-mist-fire-extinguishing-technology','gases','Chen, Wang, Yankin, Neyasov (2019): обзор механизмов пожаротушения водяным туманом; не является испытанием в космосе.','reviewed'),
 ('spacecraft-fire-safety','Пожарная безопасность космических аппаратов','https://cyberleninka.ru/article/n/pozharnaya-bezopasnost-kosmicheskih-apparatov','screwups','Малина, Якимова (2013): профилактика, обнаружение, тушение пожаров на космических аппаратах.','reviewed'),
]
def connect():
 DB.parent.mkdir(parents=True,exist_ok=True)
 con=sqlite3.connect(DB,timeout=15)
 con.row_factory=sqlite3.Row
 return con

def init_db():
 with LOCK,connect() as con:
  con.execute("""CREATE TABLE IF NOT EXISTS measurements (id INTEGER PRIMARY KEY, unique_key TEXT UNIQUE NOT NULL, test_id TEXT NOT NULL, program TEXT NOT NULL, material TEXT, pressure_kpa REAL, pressure_min_kpa REAL, pressure_max_kpa REAL, oxygen_pct REAL, flow_cm_s REAL, outcome TEXT, source_id TEXT, source_url TEXT, source_page TEXT, status TEXT NOT NULL DEFAULT 'imported', note TEXT DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP)""")
  con.execute("""CREATE TABLE IF NOT EXISTS articles (slug TEXT PRIMARY KEY, title TEXT, url TEXT, topic TEXT, summary TEXT, status TEXT)""")
  for a in ARTICLES:con.execute('INSERT OR IGNORE INTO articles VALUES (?,?,?,?,?,?)',a)
  if con.execute('SELECT COUNT(*) FROM measurements').fetchone()[0]:return
  root=ROOT/'data'/'processed'
  def read(name):
   with (root/name).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
  def num(v):
   try:return float(v) if v is not None and str(v).strip() else None
   except (TypeError,ValueError):return None
  def add(key,test,program,material,p,o,flow,outcome,source,page):
   pmin=pmax=None
   if isinstance(p,str) and "-" in p:
    try:pmin,pmax=map(float,p.split("-",1));p=None
    except ValueError:p=None
   if pmin is None and isinstance(p,(int,float)):pmin=pmax=p
   con.execute("""INSERT OR IGNORE INTO measurements (unique_key,test_id,program,material,pressure_kpa,pressure_min_kpa,pressure_max_kpa,oxygen_pct,flow_cm_s,outcome,source_id,source_url,source_page,status) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
    (key,test,program,material,p,pmin,pmax,o,flow,outcome,source,'',str(page or ''),'imported'))
  for r in read('microfire-atlas-bass2-tests.csv'):
   add('bass:'+r['id'],r['test_id'],r['investigation'],r['material'],r['pressure_kpa'],num(r['oxygen_vol_pct']),num(r['flow_final_cm_s']),r['outcome_label'],r['source_id'],r['pdf_page'])
  for r in read('microfire-atlas-saffire-runs.csv'):
   add('saffire:'+r['id'],r['flight']+' · '+r['sample'],'Saffire',r['material'],num(r['pressure_kpa']),num(r['o2_pct']),num(r['flow_cm_s']),r['outcome_label'],r['conditions_source'] or r['results_source'],r['conditions_pdf_page'] or r['results_pdf_page'])
  for r in read('microfire-atlas-luci-runs.csv'):
   add('luci:'+r['id'],'LUCI · '+r['sample'],'LUCI',r['material'],num(r['pressure_kpa']),num(r['o2_start_pct']),None,r['outcome_label'],r['source_id'],r['outcome_pdf_page'])

def valid(payload):
 errors=[]
 for name in ('test_id','program'):
  if not str(payload.get(name,'')).strip():errors.append(name+' is required')
 if payload.get('program') not in ALLOWED:errors.append('Unknown program')
 for name,low,high in [('pressure_kpa',0,200),('oxygen_pct',0,100),('flow_cm_s',0,1000)]:
  val=payload.get(name)
  if val in ('',None):payload[name]=None;continue
  try:
   val=float(val)
   if not math.isfinite(val) or not low<=val<=high:raise ValueError()
   payload[name]=val
  except (ValueError,TypeError):errors.append(name+' out of range')
 for name in ('test_id','material','outcome','source_id','source_url','source_page','note'):
  payload[name]=str(payload.get(name) or '').strip()[:1000]
 url=payload['source_url']
 if url and not url.startswith(('https://','http://')):errors.append('Source URL must be http(s)')
 if payload.get('status') not in ('draft','reviewed'):errors.append('Invalid status')
 if payload.get('status')=='reviewed' and not (url or payload['source_id']):errors.append('Reviewed entry requires a source')
 return errors

def metrics(rows):
 known=[r for r in rows if (r['pressure_kpa'] is not None or r['pressure_min_kpa'] is not None) and r['oxygen_pct'] is not None]
 pairs=Counter((r['program'],r['test_id']) for r in rows)
 return {'records':len(rows),'plotted':len(known),'missing_pressure':sum(r['pressure_kpa'] is None and r['pressure_min_kpa'] is None for r in rows),'pressure_ranges':sum(r['pressure_min_kpa'] is not None and r['pressure_max_kpa'] is not None and r['pressure_min_kpa']!=r['pressure_max_kpa'] for r in rows),'missing_oxygen':sum(r['oxygen_pct'] is None for r in rows),'duplicate_test_labels':[{'program':p,'test_id':t,'count':n} for (p,t),n in pairs.items() if n>1], 'by_program':dict(Counter(r['program'] for r in rows)),'by_status':dict(Counter(r['status'] for r in rows))}

class Handler(SimpleHTTPRequestHandler):
 def __init__(self,*args,**kwargs):super().__init__(*args,directory=str(ROOT),**kwargs)
 def send_json(self,data,status=200):
  b=json.dumps(data,ensure_ascii=False,allow_nan=False).encode('utf-8')
  self.send_response(status);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Content-Length',str(len(b)));self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(b)
 def admin(self):
  token=os.environ.get('MICROFIRE_ADMIN_TOKEN','')
  return bool(token) and self.headers.get('X-Admin-Token')==token
 def do_GET(self):
  path=urlparse(self.path).path
  if path in ('/','/index.html'):
   self.path='/index.html';return super().do_GET()
  if path.startswith('/api/'):
   with LOCK,connect() as con:
    if path=='/api/measurements':return self.send_json([dict(x) for x in con.execute('SELECT * FROM measurements ORDER BY id')])
    if path=='/api/articles':return self.send_json([dict(x) for x in con.execute('SELECT * FROM articles')])
    if path=='/api/quality':return self.send_json(metrics([dict(x) for x in con.execute('SELECT * FROM measurements')]))
   return self.send_json({'error':'Not found'},404)
  if path.startswith('/data/') or path.startswith('/src/') or path.endswith('.py') or path.endswith('.sqlite3') or path.startswith('/.'):
   return self.send_json({'error':'Forbidden'},403)
  return super().do_GET()
 def do_POST(self):
  if urlparse(self.path).path!='/api/measurements':return self.send_json({'error':'Not found'},404)
  if not self.admin():return self.send_json({'error':'Admin token required'},403)
  try:
   length=int(self.headers.get('Content-Length','0'))
   if length>50000:return self.send_json({'error':'Payload too large'},413)
   data=json.loads(self.rfile.read(length))
   errors=valid(data)
   if errors:return self.send_json({'errors':errors},422)
   key='manual:'+datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S%f')
   with LOCK,connect() as con:
    cur=con.execute("""INSERT INTO measurements (unique_key,test_id,program,material,pressure_kpa,pressure_min_kpa,pressure_max_kpa,oxygen_pct,flow_cm_s,outcome,source_id,source_url,source_page,status,note) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
      (key,data['test_id'],data['program'],data['material'],data['pressure_kpa'],data['pressure_kpa'],data['pressure_kpa'],data['oxygen_pct'],data['flow_cm_s'],data['outcome'],data['source_id'],data['source_url'],data['source_page'],data['status'],data['note']))
   return self.send_json({'ok':True,'id':cur.lastrowid},201)
  except (json.JSONDecodeError,ValueError,KeyError) as e:return self.send_json({'error':str(e)},400)
  except sqlite3.Error as e:return self.send_json({'error':'Database error: '+str(e)},500)
 def log_message(self,format,*args):super().log_message(format,*args)

if __name__=='__main__':
 init_db()
 host=os.environ.get('MICROFIRE_HOST','127.0.0.1')
 port=int(os.environ.get('MICROFIRE_PORT','8502'))
 print(f'Microfire Atlas http://{host}:{port} | editing requires MICROFIRE_ADMIN_TOKEN')
 ThreadingHTTPServer((host,port),Handler).serve_forever()
